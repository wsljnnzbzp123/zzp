<?php
namespace api\controllers;
use Yii;
use yii\web\Controller;
/**
 * Site controller
 */
class CommonController extends Controller
{

    public function init(){

        if (!$this->checkSign()){

            echo  json_encode(['error_code'=>Yii::$app->params['errorCode']['w-r']]);exit();

        }

    }

    public function  checkSign(){

        $sign = Yii::$app->request->get('sign','');

        $time = Yii::$app->request->get('time','');

        $arr = Yii::$app->request->get();

//        unset($arr['sign']);
//        unset($arr['time']);
//        unset($arr['r']);
//        unset($arr['where']);
//        unset($arr['id']);

        if (!$sign){
            //返回错误编码
            echo json_encode(['error_code'=>Yii::$app->params['errorCode']['ns']]);exit();
        }

        if (!$time){
            //返回错误编码
            echo json_encode(['error_code'=>Yii::$app->params['errorCode']['nt']]);exit();
        }

        $token = 'zzply';

//        sort($arr);
//
//        $str = '';
//
//        foreach ($arr as $key=>$val){
//
//            $str .= $key.$val;
//
//        }

        $checkSign = sha1($token.$time);

        if ($sign==$checkSign){

            return true;

        }else{

            return false;

        }
    }

}