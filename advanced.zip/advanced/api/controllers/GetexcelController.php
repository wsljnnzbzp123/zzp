<?php
namespace api\controllers;
use Yii;
use yii\web\Controller;
require '../../common/excelclass/Classes/PHPExcel.php';
/**
 * Site controller
 */
header('content-type:text/html;charset=utf-8');
class GetexcelController extends Controller
{
    public $enableCsrfValidation = false;

    public function actionGetfile(){

        $path = $_POST['path'];

        $unit = $_POST['unit'];

        $month = $_POST['month'];

        //找到Excel表格
        $objPHPExcel = \PHPExcel_IOFactory::load($path);

        //获取活动表
        $sheet  = $objPHPExcel->getActiveSheet();
//
//        $rows   = $sheet->getHighestRow();
//
//        $cols   = $sheet->getHighestColumn();
//
//        //循环拿值
//        for ($i=1;$i<=$rows;$i++){
//            for ($j='A';$j<=$cols;$j++){
//                $data[$i-1][] = $sheet->getCell($j.$i)->getValue();
//            }
//        }
        //简便方法
        $data = $sheet->toArray(null,true,true,true);

        unset($data[1]);

        //试题类型
        $type = array_flip(Yii::$app->params['type']);

        //分数
        $score = Yii::$app->params['score'];

        $time = time();

        foreach ($data as $key => $value) {

            $title_data = array(
                'month'=>$month,
                'unit'=>$unit,
                'type'=>$type[$value['B']],
                'addtime'=>$time,
                'value'=>$score[$type[$value['B']]],
                'sendman'=>$value['L'],
                'question'=>$value['C']
            );

            $res = Yii::$app->db->createCommand()->insert('pro_title',$title_data)->execute();

            $title_id=Yii::$app->db->getLastInsertID();

            $an_num = array('D'=>'A','E'=>'B','F'=>'C','G'=>'D','H'=>'E','I'=>'F');

            //正确答案
            $right_answer = str_split($value['J'],1);

            //试题答案
            for ($i = 'D';$i<='I';$i++){

                if (empty($value[$i])) continue;

                //判断是否正确
                $is_yes = in_array($an_num[$i],$right_answer)? 1 : 0;

                //答案数据
                $answer_data = array(
                    'title_id'=>$title_id,
                    'option'=>$value[$i],
                    'is_right'=>$is_yes
                );

                //执行添加
                $ress = Yii::$app->db->createCommand()->insert('pro_answer',$answer_data)->execute();

            }

        }

        if ($res&&$ress){
            echo 1;
        }



    }
}
