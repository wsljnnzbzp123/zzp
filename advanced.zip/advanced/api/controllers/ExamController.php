<?php
namespace api\controllers;
use Yii;
use yii\web\Controller;
/**
 * Site controller
 */
class ExamController extends CommonController
{
    public function actionGetmsg(){

        $sql = "select DISTINCT month,unit,addtime from pro_title ORDER BY addtime desc";

        $data= Yii::$app->db->createCommand($sql)->queryAll();

        foreach ($data as $key=>$val){

            $data[$key]['month_cn'] = Yii::$app->params['month'][$val['month']];

            $data[$key]['unit_cn'] = Yii::$app->params['unit'][$val['unit']];

        }

        return json_encode($data);



    }

    public function actionGetallmsg(){

        $id = Yii::$app->request->get('id','');

        $sql = "select * from pro_title where addtime = '$id'";

        $data= Yii::$app->db->createCommand($sql)->queryAll();

        $type = Yii::$app->params['type'];



        foreach ($data as $key=>$val){

            $id = $val['id'];

            $sql = "select * from pro_answer where title_id = '$id'";

            $answer= Yii::$app->db->createCommand($sql)->queryAll();

            $data[$key]['answer'] = $answer;

            $data[$key]['type']=$type[$val['type']];

            $bz = 'A';

            foreach ($data[$key]['answer'] as $k=>$v){

                $data[$key]['answer'][$k]['bz'] = $bz;

                $bz++;

            }

        }



        return json_encode($data);

    }
}