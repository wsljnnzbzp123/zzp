<?php
/* @var $this yii\web\View */
?>
<table class="table table-hover">
    <thead>

    </thead>
    <tbody>
    <form action="index.php?r=index/madevalue" method="post">
        <?php foreach ($data as $key => $value) {?>
            <div class="panel panel-default">
                <div class="panel-heading"><?=$key+1?>. [<?=$value['type']?>] ( <font color="#428BCA"><?=$value['value']?></font>  分)<?=$value['question']?></div>
            </div>
            <?php foreach ($value['answer'] as $k => $v) { if ($value['type']=='2-多选'){ ?>
                <ul class="list-group">
                    <li class="list-group-item"><input type="checkbox" value="<?=$v['id']?>" name="<?=$v['title_id']?>[]">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?=$v['bz']?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?=$v['option']?></li>
                </ul>
                <?php }else{ ?>
                <ul class="list-group">
                    <li class="list-group-item"><input type="radio" value="<?=$v['id']?>" name="<?=$v['title_id']?>">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?=$v['bz']?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?=$v['option']?></li>
                </ul>
            <?php } } ?>
        <?php } ?>
            <tr>
                <th style="text-align: center" ><input type="submit" class="btn btn-primary"></th>
            </tr>
    </form>
    </tbody>

</table>