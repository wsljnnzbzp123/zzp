<?php
/* @var $this yii\web\View */
?>

<center>
    <div class="head-title"><h3>软工考试</h3></div>
    <div>
        <form action="index.php?r=index/testsome" method="post">
        <table class="table" id="content" >
            <thead>
            <tr>
                <th><input type="checkbox" id="checkall">全选 </th>
                <th>试题年月</th>
                <th>试题名称</th>
                <th>添加时间</th>
                <th>操作</th>
            </tr>
            </thead>
            <tbody >
            <?php foreach ($data as $key => $value) { ?>
                <tr>
                    <th><input type="checkbox" class="box" name="<?=$value['month']?>[]" value="<?=$value['unit']?>"></th>
                    <th scope="row"><?=$value['month_cn']?></th>
                    <td><?=$value['unit_cn']?></td>
                    <td><?=date("Y年m月d日h:m:s",$value['addtime'])?></td>
                    <td>
                        <input type="button" class="btn btn-primary" onclick="location.href='index.php?r=index/starttest&word=<?=$value['addtime']?>'" value="开始考试">
                    </td>
                </tr>
            <?php } ?>
            </tbody>
        </table>
            <input type="submit"  id="c-all" class="btn btn-success" value="选中项考试">
        </form>
    </div>
</center>
<script>
    $(document).on("click","#checkall",function () {
        if ($(this).prop('checked')){
            $(".box").prop('checked',true)
        } else{
            $(".box").prop('checked',false)
        }

    })
</script>




