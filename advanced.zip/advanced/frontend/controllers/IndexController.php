<?php
namespace frontend\controllers;

use Yii;
use yii\base\InvalidParamException;
use yii\web\BadRequestHttpException;
use yii\web\Controller;
use yii\filters\VerbFilter;
use yii\filters\AccessControl;
use common\models\LoginForm;
use frontend\models\PasswordResetRequestForm;
use frontend\models\ResetPasswordForm;
use frontend\models\SignupForm;
use frontend\models\ContactForm;

/**
 * Site controller
 */
class IndexController extends Controller
{
    public $layout = 'frontend.php';

    public $enableCsrfValidation = false;


    public function actionIndex(){

        //调用查询题目接口

        $sign = $this->sign();

        $url = "https://www.zzply.top/Newyii/advanced/api/web/index.php?r=exam/getmsg";

        $arrMsg = array(
            'sign'=>$sign['sign'],
            'time'=>$sign['time'],
            'where'=>'',
            'id'=>''
        );

        $data = Yii::$app->curl->_get($url,$arrMsg);

        $data = json_decode($data,true);

        return $this->render('index',['data'=>$data]);

    }

    //开始考试
    public function actionStarttest(){

        $times = Yii::$app->request->get();

        $times = $times['word'];

        $sign = $this->sign();

        $url = "https://www.zzply.top/Newyii/advanced/api/web/index.php?r=exam/getallmsg";

        $arrMsg = array(
            'sign'=>$sign['sign'],
            'time'=>$sign['time'],
            'where'=>'',
            'id'=>$times,
        );

        $data = Yii::$app->curl->_get($url,$arrMsg);

        $data = json_decode($data,true);

        return $this->render('answer',['data'=>$data]);
    }

    //考部分
    public function actionTestsome(){

        $data = Yii::$app->request->post();

        $where = "AND 1=1 ";

        if ($data){

            $where.="AND (";

            foreach ($data as $key=>$val){

                $where.="(month = $key and";

                $unit = implode(',',$val);

                $where.=" unit in ( $unit ))) OR ";

            }

            $where = mb_substr($where,0,strlen($where)-3);
        }

        $sql = "select * from pro_answer as a JOIN 
                (select * from pro_title where type = 'p-1' ".$where." ORDER BY RAND() LIMIT 20 ) 
                  as b ON a.title_id = b.id  ";

        $OneChoseData = Yii::$app->db->createCommand($sql)->queryAll();

        foreach ($OneChoseData as $key=>$val){

            

        }

    }

    //计算分数
    public function actionMadevalue(){

        $data = Yii::$app->request->post();

        $examCode = 0;

        foreach ($data as $key=>$val){

            if (is_array($val)){

                $newAr = '';

                $sendAr = '';

                $sql = "select id from pro_answer where title_id = '$key' and is_right = 1";

                $newArr = Yii::$app->db->createCommand($sql)->queryAll();

                foreach ($newArr as $ks=>$vs){

                    $newAr[] = $vs['id'];

                }

                $sendAr = $val;

                sort($newAr);

                sort($sendAr);

                $num = 2;

                if ($newAr==$sendAr){

                    $examCode = $examCode+2;

                }

            }else{

                $sql = "select is_right from pro_answer where id = '$val'";

                $is_right = Yii::$app->db->createCommand($sql)->queryOne();

                $is_right = $is_right['is_right'];

                $sqls = "select value from pro_title where id = '$key'";

                $num = Yii::$app->db->createCommand($sqls)->queryOne();

                $num = $num['value'];

                if ($is_right==1){

                    $examCode = $examCode+$num;

                }

            }

        }

        echo $examCode;

    }


    public  function sign(){

        //用户密钥
        $token = 'zzply';

//        $msg = array(
//            'user'=>$user,
//            'age'=>$age
//        );
//
//        sort($msg);
//
//        $str = '';
//
//        foreach ($msg as $key=>$val){
//
//            $str .= $key.$val;
//
//        }

        $time = time();

        $sign = sha1($token.$time);

        return ['sign'=>$sign,'time'=>$time];

    }

}