<?php
namespace backend\controllers;
use Yii;
use yii\web\Controller;
use yii\filters\VerbFilter;
use yii\filters\AccessControl;
use common\models\LoginForm;
/**
 * Site controller
 */
class IndexController extends Controller
{

    public $enableCsrfValidation = false;

    public function actionExampage(){

        $sql = "select DISTINCT month,unit,addtime from pro_title ORDER BY addtime desc";

        $data= Yii::$app->db->createCommand($sql)->queryAll();

        return $this->render('exam_page',['data'=>$data]);

    }

    //查看详情页面
    public function actionCheck_info(){

        $time = Yii::$app->request->get();

        $time = $time['word'];

        $sql = "select * from pro_title WHERE addtime = '$time'";

        $data= Yii::$app->db->createCommand($sql)->queryAll();

        //试题类型
        $type = Yii::$app->params['type'];

        foreach ($data as $key => $value) {
            $data[$key]['type']=$type[$value['type']];
        }

        return $this->render('exam_info',['data'=>$data]);

    }

    public function actionSendexcel()
    {

        return $this->render('send_excel');
    }


    public function actionGetfile(){

        $month = $_POST['month'];

        $unit = $_POST['unit'];

        $data = $_FILES['file'];


        $path = '/phpstudy/www/Newyii/advanced/common/excel/'.$data['name'];

        $res = move_uploaded_file($data['tmp_name'],$path);

        $rdata = Yii::$app->curl->_post('https://www.zzply.top/Newyii/advanced/api/web/index.php?r=getexcel/getfile',array('path'=>$path,'unit'=>$unit,'month'=>$month));

        if ($rdata){

            $this->redirect(array('index/sendexcel'));

        }

    }

}
