<?php
/* @var $this yii\web\View */
?>
<link href="/Newyii/advanced/backend/web/css/send.css" rel="stylesheet">
<center class="box">
    <div class="head-title">
        <h2>试题导入</h2>
    </div>
    <div class="put-file">
        <form action="index.php?r=index/getfile" method="post" enctype="multipart/form-data">
                <label for="name">选择月份</label>
                <select class="form-control" style="width: 40%" name="month">
                    <option>请选择月份</option>
                    <?php foreach (Yii::$app->params['month'] as $key=>$val){?>
                        <option  value="<?=$key?>"><?=$val?></option>
                    <?php }?>
                </select>

                <label for="name" style="margin-top: 1em">选择单元</label>
                <select class="form-control" style="width: 40%" name="unit">
                    <option >请选择单元</option>
                    <?php foreach (Yii::$app->params['unit'] as $key=>$val){?>
                        <option  value="<?=$key?>"><?=$val?></option>
                    <?php }?>
                </select>


            <input type="file" name="file" class="btn btn-info" id="file">
            <input type="submit" value="提交" class="btn btn-success" id="btn">
        </form>
    </div>
</center>
<div class="content">

</div>