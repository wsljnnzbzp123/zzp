<?php
/* @var $this yii\web\View */
?>
<link href="/Newyii/advanced/backend/web/css/exams.css" rel="stylesheet">
<div>
    <center>
        <div class="head-title">
            <h1>试题详情</h1>
        </div>
        <div>
            <table class="table" id="content" >
                <thead>
                <tr>
                    <th>单元</th>
                    <th>试题</th>
                    <th>类型</th>
                    <th>分数值</th>
                    <th>出题人</th>
                </tr>
                </thead>
                <tbody >
                <?php foreach ($data as $key => $value) { ?>
                    <tr>
                        <th scope="row"><?=$value['unit']?></th>
                        <th><?=mb_substr($value['question'],'0','15','utf8').'......'?></th>
                        <td><?=$value['type']?></td>
                        <td><?=$value['value']?></td>
                        <td>
                            <button class="btn btn-danger" >删除</button>
                        </td>
                    </tr>
                <?php } ?>
                </tbody>
            </table>
        </div>
    </center>

</div>
