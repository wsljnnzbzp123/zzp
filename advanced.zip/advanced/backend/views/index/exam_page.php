<?php
/* @var $this yii\web\View */
?>
<link href="/Newyii/advanced/backend/web/css/exams.css" rel="stylesheet">
<center>
    <div>
        <div class="head-title">
            <h1>试题管理页</h1>
        </div>
        <div class="save-but">
            <button class="btn btn-primary" id="add">添加试题</button>
        </div>
    </div>
    <div>
        <table class="table" id="content" >
            <thead>
            <tr>
                <th>试题年月</th>
                <th>试题名称</th>
                <th>添加时间</th>
                <th>操作</th>
            </tr>
            </thead>
            <tbody >
            <?php foreach ($data as $key => $value) { ?>
                <tr>
                    <th scope="row"><?=$value['month']?></th>
                    <td><?=$value['unit']?></td>
                    <td><?=date("Y年m月d日h:m:s",$value['addtime'])?></td>
                    <td>
                        <button class="btn btn-success" onclick="location.href='index.php?r=index/check_info&word=<?=$value['addtime']?>' ">查看详情</button>
                        <button class="btn btn-danger" >删除</button>
                    </td>
                </tr>
            <?php } ?>
            </tbody>
        </table>
    </div>
</center>
<script>
    $(document).on("click","#add",function(){
        alert(8520)
    })
</script>


